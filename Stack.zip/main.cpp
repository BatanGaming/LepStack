#include <iostream>
#include <chrono>
#include "Stackl.h"
#include "Stackm.h"
#include "Stackmm.h"
#include <stack>
#include <vector>
#include <algorithm>

using Graph = std::vector<std::vector<size_t>>;

template<class StackT>
double test(StackT& stack, int n,int m) {
	auto start = std::chrono::high_resolution_clock::now();
	for (int j = 0; j < m; ++j) {
		for (int i = 0; i < n; ++i)
			stack.push(i);
		for (int i = 0; i < n; ++i)
			stack.pop();
	}
	auto end = std::chrono::high_resolution_clock::now();
	return (end - start).count() * 1e-9;
}

template<class StackT>
double test2(StackT& stack, int n, int m, double p) {
	auto start = std::chrono::high_resolution_clock::now();
	for (int j = 0; j < m; ++j) {
		if(rand() % 100 <= p * 100) {
			for (int i = 0; i < n; ++i)
				stack.push(i);
		}
		else {
			if (!stack.empty())
				for (int i = 0; i < n; ++i)
					stack.pop();
		}
	}
	auto end = std::chrono::high_resolution_clock::now();
	return (end - start).count() * 1e-9;
}

template<typename StackT>
bool checkParentheses(const std::string& str) {
	StackT stack;
	std::string open("<({[");
	std::string close(">)}]");
	for (size_t i = 0; i < str.size(); ++i) {
		if (open.find(str[i]) != std::string::npos)
			stack.push(str[i]);
		else if (open.find(stack.top()) == close.find(str[i]))
			stack.pop();
		else
			return false;
	}
	return true;
}

template<typename StackT>
std::vector<size_t> findPath(Graph graph) {
	auto it = std::find_if(graph.begin(), graph.end(), [](const auto& list) {
		return list.size() % 2 == 1;
		});
	std::vector<size_t> path;
	StackT stack;
	stack.push(it == graph.end() ? 0 : it - graph.begin());
	while(!stack.empty()) {
		if (graph[stack.top()].empty()) {
			path.push_back(stack.top());
			stack.pop();
			continue;
		}
		auto u = graph[stack.top()].back();
		std::swap(*std::find(graph[u].begin(), graph[u].end(), stack.top()), graph[u].back());
		graph[u].pop_back();
		graph[stack.top()].pop_back();
		stack.push(u);
	}
	return path;
}

int main(int argc, char* argv[]) {
	std::vector<int> vec;
	const int n = atoi(argv[1]);
	const int m = atoi(argv[2]);
	const double p = atof(argv[3]);
	Stackm<int> stackm(n*m);
	std::cout << "Stackm: " << test2(stackm, n,m, p) << std::endl;
	Stackl<int> stackl;
	std::cout << "Stackl: " << test2(stackl, n,m, p) << std::endl;
	Stackmm<int> stackmm;
	std::cout << "Stackmm: " << test2(stackmm, n,m, p) << std::endl;
	std::stack<int> stack;
	std::cout << "std::stack: " << test2(stack, n, m, p) << std::endl;
	return 0;
}